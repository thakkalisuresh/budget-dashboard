
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-subscribe.mjs
import { getStore } from "@netlify/blobs";
var ALLOWED_EMAILS = new Set(
  (process.env.ALLOWED_EMAILS || "").split(",").map((e) => e.trim().toLowerCase())
);
async function handler(req) {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
  try {
    const { subscription, email, preferredHour, timezoneOffset } = await req.json();
    if (!email || !subscription?.endpoint) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
    }
    if (ALLOWED_EMAILS.size > 0 && !ALLOWED_EMAILS.has(email.toLowerCase())) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 403 });
    }
    const store = getStore("push-subscriptions");
    await store.setJSON(email.toLowerCase(), {
      email: email.toLowerCase(),
      subscription,
      preferredHour: preferredHour ?? 20,
      // default 8pm
      timezoneOffset: timezoneOffset ?? 0,
      // hours offset from UTC (positive = east)
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    console.error("push-subscribe error:", e);
    return new Response(JSON.stringify({ error: "Internal error" }), { status: 500 });
  }
}
var config = { path: "/api/push-subscribe" };
export {
  config,
  handler as default
};
