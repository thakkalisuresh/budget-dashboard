
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-unsubscribe.mjs
import { getStore } from "@netlify/blobs";
async function handler(req) {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
  try {
    const { email } = await req.json();
    if (!email) return new Response(JSON.stringify({ error: "Missing email" }), { status: 400 });
    const store = getStore("push-subscriptions");
    await store.delete(email.toLowerCase());
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    console.error("push-unsubscribe error:", e);
    return new Response(JSON.stringify({ error: "Internal error" }), { status: 500 });
  }
}
var config = { path: "/api/push-unsubscribe" };
export {
  config,
  handler as default
};
