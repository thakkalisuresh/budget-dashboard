
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-digest.mjs
import webpush from "web-push";
import { getStore } from "@netlify/blobs";
var VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY;
var VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;
var VAPID_EMAIL = process.env.VAPID_EMAIL || "mailto:nair.sabarish97@gmail.com";
async function handler() {
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    console.warn("push-digest: VAPID keys not configured");
    return new Response("VAPID not configured", { status: 200 });
  }
  webpush.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC, VAPID_PRIVATE);
  const store = getStore("push-subscriptions");
  const { blobs } = await store.list();
  const currentUTCHour = (/* @__PURE__ */ new Date()).getUTCHours();
  let sent = 0, skipped = 0, failed = 0;
  for (const blob of blobs) {
    try {
      const entry = await store.get(blob.key, { type: "json" });
      if (!entry?.subscription?.endpoint) {
        skipped++;
        continue;
      }
      const localHourUTC = ((entry.preferredHour ?? 20) - (entry.timezoneOffset ?? 0) + 24) % 24;
      if (currentUTCHour !== Math.round(localHourUTC)) {
        skipped++;
        continue;
      }
      await webpush.sendNotification(
        entry.subscription,
        JSON.stringify({
          title: "Budget Tracker",
          body: "Your daily budget digest is ready. Tap to review.",
          url: "/"
        })
      );
      sent++;
    } catch (e) {
      console.error("push-digest: failed for", blob.key, e.statusCode ?? e.message);
      if (e.statusCode === 410) {
        await store.delete(blob.key).catch(() => {
        });
      }
      failed++;
    }
  }
  console.log(`push-digest: sent=${sent} skipped=${skipped} failed=${failed}`);
  return new Response(JSON.stringify({ sent, skipped, failed }), { status: 200 });
}
var config = {
  schedule: "0 * * * *"
  // every hour on the hour
};
export {
  config,
  handler as default
};
